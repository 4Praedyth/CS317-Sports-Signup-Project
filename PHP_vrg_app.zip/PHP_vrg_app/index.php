<?php
require_once 'init.php'; // database connection, etc.
// no security check for this page


if ( isset($_SESSION["userid"]) ) {
  // They are already signed in, so cant be on this page
  if ($_SESSION["is_admin"] == 0) {
    header("Location: welcome.php");
  }
  else {
    header("Location: welcomeAdmin.php");
  }
  exit;
}
else if ( isset($_GET["userid"]) ) {
  // login form submitted

  $userid = trim($_GET["userid"]);
  $password = trim($_GET["password"]);

  $sql = "SELECT * FROM vrg_app_member
            WHERE username = '$userid' AND password= '$password'";
  //var_dump($sql);exit;

  $result = db_query($sql);


  if($result->num_rows > 0) {
      // Should only be one row since enforcing unique user names in acct signup
      $row = $result->fetch_assoc();

      //Set session variables
      $_SESSION["userid"] = $userid;
      $_SESSION["fullname"] = $row["firstname"] . " " . $row["lastname"];
      $_SESSION["is_admin"] = $row["is_admin"];

      if ($row["is_admin"] == 0) {
        header("Location: welcome.php");
      }
      else {
        header("Location: welcomeAdmin.php");
      }
      exit;
  }
  else {
    $message = "Login Attempt Failed. Please Try Again";  // fall back through to form with message
  }
}

if ( isset($_GET['message']) ) {
  switch ($_GET['message']){
    case 'account_created':
        $message = 'Your Account was created';
        break;
    case 'not_signed_in':
        $message = 'You must be Signed in to Access that Page.';
        break;
    case 'admin_access_only':
        $message = 'Only Administrators can Access that Page.';
        break;
    case 'logged_out':
        $message = 'You have been Logged Out. Thank you for using View Ridge Gallery.';
        break;
    default:
        // no message
  } //end switch
}

?>
<!DOCTYPE html>
<html>
<head><title>View Ridge Gallery</title></head>

<body>
<h1>Welcome to the View Ridge Gallery</h1>

<? if (isset($message)) { ?>
    <h1><?= $message ?></h1>
<? } ?>

<h3>Please Sign In to Access the Gallery</h3>
<form action="index.php" method="GET">
    Username: <input type="text" name="userid">
    <br><br>
    Password: <input type="password" name="password">
    <br><br>
    Don't have an account yet? <a href="signup.php">Sign up here</a>.
    <br><br>

    <input type="submit" value="Sign In">
    &nbsp;&nbsp;
    <input type="reset" value="Clear">
</form>

</body>
</html>