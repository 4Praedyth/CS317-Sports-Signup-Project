<?php
require_once 'init.php';

$page_access_level = 'admin'; // set to 'user' or 'admin' before including security check
require_once 'securityCheck.php'; // Must be logged in to get past here

?>
<!DOCTYPE html>
<html>
<head><title>Admin at View Ridge Gallery</title></head>

<body>
<hr>
<?=$_SESSION["fullname"]?> is Signed In.  <a href="securityCheck.php?log_out=yes">Sign Out</a>
<hr>

<h1>Administrator Dashboard - View Ridge Gallery</h1>

Stuff in this page only for Administrators.  Note the different page access level before the security check.

<br><br>

You are signed in as an Administrator, but can still access regular member pages.

<ul>
  <li> <a href="searchArtists.php">Search for an Artist</a></li>
  <li>
    <a href="searchPaintings.php">Search for a Painting</a>
  <small>(The search pages are similar, but this one has a bit more functionality.)</small>
  </li>
</ul>

</body>
</html>