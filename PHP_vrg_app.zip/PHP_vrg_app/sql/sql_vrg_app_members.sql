CREATE TABLE `vrg_app_member` (`firstname` VARCHAR(30) NOT NULL , `lastname` VARCHAR(30) NOT NULL , `username` VARCHAR(16) NOT NULL , `password` VARCHAR(16) NOT NULL , `is_admin` BOOLEAN NOT NULL , PRIMARY KEY (`username`)) ENGINE = InnoDB;

INSERT INTO `vrg_app_member` (`firstname`, `lastname`, `username`, `password`, `is_admin`) VALUES
  ('System', 'Admin', 'admin', 'admin', '1'),
  ('Regular', 'User', 'user', 'user', '0')