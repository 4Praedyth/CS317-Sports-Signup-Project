<?php
require_once 'init.php';

$page_access_level = 'user'; // set to 'user' or 'admin' before including security check
require_once 'securityCheck.php'; // Must be logged in to get past here

?>
<!DOCTYPE html>
<html>
<head><title>Welcome to the View Ridge Gallery</title></head>

<body>
<hr>
<?=$_SESSION["fullname"]?> is Signed In.  <a href="securityCheck.php?log_out=yes">Sign Out</a>
<hr>

<h1>View Ridge Gallery Members Home Page</h1>

<ul>
  <li> <a href="searchArtists.php">Search for an Artist</a></li>
  <li>
    <a href="searchPaintings.php">Search for a Painting</a>
  <small>(The search pages are similar, but this one has a bit more functionality.)</small>
  </li>
</ul>

</body>
</html>