<?php
require_once 'init.php'; // database connection, etc.
// no security check for this page

// is form being submitted
if ( isset($_POST["userid"]) ) {
    $fname = trim($_POST["fname"]);
    $lname = trim($_POST["lname"]);
    $userid = trim($_POST["userid"]);
    $password = trim($_POST["password1"]);

    if ($fname=='' || $lname=='' || $userid=='' || $password=='' ) {
      $message  = "Insufficient Data Supplied"; // fall back through to form with message
    }
    else {
      //check to see if user already exists
      $sql = "SELECT * FROM vrg_app_member WHERE username = '$userid' ";
      //var_dump($sql);exit;
      $result = db_query($sql);
      if ($result->num_rows > 0) {
          $message  = "Username Already Exists!"; // fall back through to form with message
      }
      else {
          $sql = "INSERT INTO vrg_app_member(firstname,lastname,username,password, is_admin) values ('$fname','$lname','$userid','$password',0)";
          //var_dump($sql);exit;
          $result = db_query($sql);

          // transfer to login page
          header("Location: index.php?message=account_created");
          exit;
      }
    }
}

?>
<!DOCTYPE html>
<html>
<head><title>Sign up for the View Ridge Gallery</title></head>
<script>
  function checkPasswords() {
      var pass1 = document.getElementById('password1').value.trim();
      var pass2 = document.getElementById('password2').value.trim();
      if (pass1 != pass2) {
        window.alert('The passwords do not match!');
        return false;  // abort form submit
      }
      return true; // submit form
  }
</script>
<body>

<? if (isset($message)) { ?>
    <h1><?= $message ?></h1>
    Please Try Again
<? } ?>

<h1>Create an Account for the View Ridge Gallery</h1>
<h3>Please enter your information below</h3>
<form action="signup.php" method="POST" id="form1" onsubmit="return checkPasswords()">
    Firstname: <input type="text" name="fname">
    <br><br>
    Lastname: <input type="text" name="lname">
    <br><br>
    Username: <input type="text" name="userid">
    <br><br>
    Password: <input type="password" name="password1" id="password1">
    <br><br>
    Re-type Password: <input type="password" name="password2" id="password2">
    <br><br>

    <br><br>
    <input type="submit" value="Sign Up">
    &nbsp;&nbsp;
    <input type="reset" value="Clear">
</form>


</body>
</html>